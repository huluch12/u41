/*
  # Schema update for friends feature

  1. Changes
    - Drop all existing policies to avoid conflicts
    - Recreate tables with proper relationships
    - Add updated RLS policies

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
*/

-- Drop all existing policies
DO $$ 
BEGIN
  -- Drop policies for profiles
  DROP POLICY IF EXISTS "Public profiles are viewable by everyone" ON profiles;
  DROP POLICY IF EXISTS "Users can update their own profile" ON profiles;
  DROP POLICY IF EXISTS "Users can update own profile" ON profiles;
  
  -- Drop policies for workouts
  DROP POLICY IF EXISTS "Users can view their own workouts" ON workouts;
  DROP POLICY IF EXISTS "Users can create their own workouts" ON workouts;
  DROP POLICY IF EXISTS "Users can update their own workouts" ON workouts;
  DROP POLICY IF EXISTS "Users can delete their own workouts" ON workouts;
  
  -- Drop policies for exercises
  DROP POLICY IF EXISTS "Users can view exercises from their workouts" ON exercises;
  DROP POLICY IF EXISTS "Users can create exercises in their workouts" ON exercises;
  
  -- Drop policies for workout_logs
  DROP POLICY IF EXISTS "Users can view their own workout logs" ON workout_logs;
  DROP POLICY IF EXISTS "Users can create their own workout logs" ON workout_logs;
  
  -- Drop policies for friendships if they exist
  DROP POLICY IF EXISTS "Users can view their friendships" ON friendships;
  DROP POLICY IF EXISTS "Users can create friendship requests" ON friendships;
  DROP POLICY IF EXISTS "Users can update their friendship status" ON friendships;
  DROP POLICY IF EXISTS "Users can delete their friendships" ON friendships;
END $$;

-- Drop and recreate friendships table
DROP TABLE IF EXISTS friendships CASCADE;

-- Create friendships table with proper relationships
CREATE TABLE friendships (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES profiles(id),
  friend_id UUID NOT NULL REFERENCES profiles(id),
  status TEXT CHECK (status IN ('pending', 'accepted', 'rejected')) DEFAULT 'pending',
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(user_id, friend_id),
  CHECK (user_id != friend_id)
);

-- Enable RLS
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE workouts ENABLE ROW LEVEL SECURITY;
ALTER TABLE exercises ENABLE ROW LEVEL SECURITY;
ALTER TABLE workout_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE friendships ENABLE ROW LEVEL SECURITY;

-- Recreate all policies

-- Profiles policies
CREATE POLICY "Public profiles are viewable by everyone"
  ON profiles FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can update own profile"
  ON profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = id);

-- Workouts policies
CREATE POLICY "Users can view own workouts"
  ON workouts FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create own workouts"
  ON workouts FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own workouts"
  ON workouts FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete own workouts"
  ON workouts FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Exercises policies
CREATE POLICY "Users can view workout exercises"
  ON exercises FOR SELECT
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM workouts
    WHERE workouts.id = exercises.workout_id
    AND workouts.user_id = auth.uid()
  ));

CREATE POLICY "Users can create workout exercises"
  ON exercises FOR INSERT
  TO authenticated
  WITH CHECK (EXISTS (
    SELECT 1 FROM workouts
    WHERE workouts.id = exercises.workout_id
    AND workouts.user_id = auth.uid()
  ));

-- Workout logs policies
CREATE POLICY "Users can view own logs"
  ON workout_logs FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create own logs"
  ON workout_logs FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

-- Friendships policies
CREATE POLICY "Users can view friendships"
  ON friendships FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id OR auth.uid() = friend_id);

CREATE POLICY "Users can create friendship requests"
  ON friendships FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update friendship status"
  ON friendships FOR UPDATE
  TO authenticated
  USING (auth.uid() = friend_id);

CREATE POLICY "Users can delete friendships"
  ON friendships FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id OR auth.uid() = friend_id);

-- Create functions
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger AS $$
BEGIN
  INSERT INTO public.profiles (id, username, full_name)
  VALUES (new.id, new.email, new.raw_user_meta_data->>'full_name');
  RETURN new;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Create trigger for new user
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();