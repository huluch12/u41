/*
  # Add sets table and update exercises table

  1. New Tables
    - `sets`
      - `id` (uuid, primary key)
      - `exercise_id` (uuid, references exercises)
      - `reps` (integer)
      - `weight` (numeric)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. Changes
    - Remove `sets`, `reps`, and `weight` from exercises table
    - Add cascade delete for sets when exercise is deleted

  3. Security
    - Enable RLS on sets table
    - Add policies for authenticated users
*/

-- Remove columns from exercises table
ALTER TABLE exercises
DROP COLUMN IF EXISTS sets,
DROP COLUMN IF EXISTS reps,
DROP COLUMN IF EXISTS weight;

-- Create sets table
CREATE TABLE IF NOT EXISTS sets (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  exercise_id UUID REFERENCES exercises(id) ON DELETE CASCADE,
  reps INTEGER NOT NULL DEFAULT 0,
  weight NUMERIC(5,2) NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Enable RLS
ALTER TABLE sets ENABLE ROW LEVEL SECURITY;

-- Sets policies
CREATE POLICY "Users can view sets from their exercises"
  ON sets FOR SELECT
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM exercises
    JOIN workouts ON workouts.id = exercises.workout_id
    WHERE exercises.id = sets.exercise_id
    AND workouts.user_id = auth.uid()
  ));

CREATE POLICY "Users can create sets for their exercises"
  ON sets FOR INSERT
  TO authenticated
  WITH CHECK (EXISTS (
    SELECT 1 FROM exercises
    JOIN workouts ON workouts.id = exercises.workout_id
    WHERE exercises.id = exercise_id
    AND workouts.user_id = auth.uid()
  ));

CREATE POLICY "Users can update sets from their exercises"
  ON sets FOR UPDATE
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM exercises
    JOIN workouts ON workouts.id = exercises.workout_id
    WHERE exercises.id = exercise_id
    AND workouts.user_id = auth.uid()
  ));

CREATE POLICY "Users can delete sets from their exercises"
  ON sets FOR DELETE
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM exercises
    JOIN workouts ON workouts.id = exercises.workout_id
    WHERE exercises.id = exercise_id
    AND workouts.user_id = auth.uid()
  ));