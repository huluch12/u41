/*
  # Add order_index to workouts table

  1. Changes
    - Add order_index column to workouts table
    - Set default value to 0
    - Update existing rows to have sequential order_index values
*/

-- Add order_index column if it doesn't exist
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns 
    WHERE table_name = 'workouts' AND column_name = 'order_index'
  ) THEN
    ALTER TABLE workouts ADD COLUMN order_index INTEGER DEFAULT 0;
    
    -- Update existing rows to have sequential order_index values
    WITH numbered_workouts AS (
      SELECT id, ROW_NUMBER() OVER (PARTITION BY day_of_week ORDER BY created_at) - 1 as new_order
      FROM workouts
    )
    UPDATE workouts
    SET order_index = numbered_workouts.new_order
    FROM numbered_workouts
    WHERE workouts.id = numbered_workouts.id;
  END IF;
END $$;