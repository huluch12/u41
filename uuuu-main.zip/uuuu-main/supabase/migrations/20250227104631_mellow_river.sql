/*
  # Create routines tables

  1. New Tables
    - `routines`
      - `id` (uuid, primary key)
      - `user_id` (uuid, references auth.users)
      - `name` (text)
      - `schedule` (jsonb)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)
    - `routine_exercises`
      - `id` (uuid, primary key)
      - `routine_id` (uuid, references routines)
      - `name` (text)
      - `sets` (integer)
      - `reps` (integer)
      - `weight` (numeric)
      - `rest_seconds` (integer)
      - `notes` (text)
      - `order_index` (integer)
    - `routine_shares`
      - `id` (uuid, primary key)
      - `routine_id` (uuid, references routines)
      - `user_id` (uuid, references auth.users)
      - `friend_id` (uuid, references auth.users)
      - `created_at` (timestamp)
  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
*/

-- Create routines table
CREATE TABLE IF NOT EXISTS routines (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  schedule JSONB DEFAULT '[]',
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Create routine_exercises table
CREATE TABLE IF NOT EXISTS routine_exercises (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  routine_id UUID REFERENCES routines(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  sets INTEGER NOT NULL DEFAULT 3,
  reps INTEGER NOT NULL DEFAULT 10,
  weight NUMERIC(5,2) DEFAULT 0,
  rest_seconds INTEGER DEFAULT 60,
  notes TEXT,
  order_index INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Create routine_shares table
CREATE TABLE IF NOT EXISTS routine_shares (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  routine_id UUID REFERENCES routines(id) ON DELETE CASCADE,
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  friend_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Enable RLS
ALTER TABLE routines ENABLE ROW LEVEL SECURITY;
ALTER TABLE routine_exercises ENABLE ROW LEVEL SECURITY;
ALTER TABLE routine_shares ENABLE ROW LEVEL SECURITY;

-- Routines policies
CREATE POLICY "Users can view their own routines"
  ON routines FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can view routines shared with them"
  ON routines FOR SELECT
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM routine_shares
    WHERE routine_shares.routine_id = routines.id
    AND routine_shares.friend_id = auth.uid()
  ));

CREATE POLICY "Users can create their own routines"
  ON routines FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own routines"
  ON routines FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own routines"
  ON routines FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- Routine exercises policies
CREATE POLICY "Users can view exercises from their routines"
  ON routine_exercises FOR SELECT
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM routines
    WHERE routines.id = routine_exercises.routine_id
    AND routines.user_id = auth.uid()
  ));

CREATE POLICY "Users can view exercises from shared routines"
  ON routine_exercises FOR SELECT
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM routine_shares
    JOIN routines ON routines.id = routine_shares.routine_id
    WHERE routines.id = routine_exercises.routine_id
    AND routine_shares.friend_id = auth.uid()
  ));

CREATE POLICY "Users can create exercises in their routines"
  ON routine_exercises FOR INSERT
  TO authenticated
  WITH CHECK (EXISTS (
    SELECT 1 FROM routines
    WHERE routines.id = routine_exercises.routine_id
    AND routines.user_id = auth.uid()
  ));

CREATE POLICY "Users can update exercises in their routines"
  ON routine_exercises FOR UPDATE
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM routines
    WHERE routines.id = routine_exercises.routine_id
    AND routines.user_id = auth.uid()
  ));

CREATE POLICY "Users can delete exercises in their routines"
  ON routine_exercises FOR DELETE
  TO authenticated
  USING (EXISTS (
    SELECT 1 FROM routines
    WHERE routines.id = routine_exercises.routine_id
    AND routines.user_id = auth.uid()
  ));

-- Routine shares policies
CREATE POLICY "Users can view shares for their routines"
  ON routine_shares FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id OR auth.uid() = friend_id);

CREATE POLICY "Users can create shares for their routines"
  ON routine_shares FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete shares for their routines"
  ON routine_shares FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);