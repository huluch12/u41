/*
  # Fix Profiles RLS Policies

  1. Changes
    - Update RLS policies for the profiles table to ensure proper access
    - Add policy for inserting new profiles
    - Fix policy for updating profiles
  
  2. Security
    - Ensure authenticated users can create their own profile
    - Ensure authenticated users can view all profiles
    - Ensure authenticated users can only update their own profile
*/

-- Drop existing policies for profiles
DROP POLICY IF EXISTS "Profiles are viewable by everyone" ON profiles;
DROP POLICY IF EXISTS "Users can update their own profile" ON profiles;

-- Create new policies with proper permissions
CREATE POLICY "Profiles are viewable by everyone"
  ON profiles FOR SELECT
  USING (true);

CREATE POLICY "Users can insert their own profile"
  ON profiles FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);

CREATE POLICY "Users can update their own profile"
  ON profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = id);