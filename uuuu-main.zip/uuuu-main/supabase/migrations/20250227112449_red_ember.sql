/*
  # Fix profile policies and add columns to routines table
  
  1. Changes
     - Safely drop and recreate profile policies
     - Add is_favorite column to routines table
     - Add description column to routines table
  
  2. Security
     - Ensure proper RLS policies for profiles
*/

-- Drop existing policies for profiles (only if they exist)
DROP POLICY IF EXISTS "Profiles are viewable by everyone" ON profiles;
DROP POLICY IF EXISTS "Users can update their own profile" ON profiles;

-- Create new policies with proper permissions (only if they don't exist)
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'profiles' AND policyname = 'Profiles are viewable by everyone'
  ) THEN
    CREATE POLICY "Profiles are viewable by everyone"
      ON profiles FOR SELECT
      USING (true);
  END IF;
  
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'profiles' AND policyname = 'Users can insert their own profile'
  ) THEN
    CREATE POLICY "Users can insert their own profile"
      ON profiles FOR INSERT
      TO authenticated
      WITH CHECK (auth.uid() = id);
  END IF;
  
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies 
    WHERE tablename = 'profiles' AND policyname = 'Users can update their own profile'
  ) THEN
    CREATE POLICY "Users can update their own profile"
      ON profiles FOR UPDATE
      TO authenticated
      USING (auth.uid() = id);
  END IF;
END $$;

-- Add is_favorite column to routines table
ALTER TABLE routines ADD COLUMN IF NOT EXISTS is_favorite BOOLEAN DEFAULT false;

-- Add description column to routines table
ALTER TABLE routines ADD COLUMN IF NOT EXISTS description TEXT;