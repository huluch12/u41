import React, { useEffect, useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { useAuthStore } from './store/authStore';
import { supabase, isSupabaseConfigured } from './lib/supabase';
import { Dumbbell, AlertTriangle } from 'lucide-react';

// Lazy load components
const Login = React.lazy(() => import('./pages/Login'));
const Dashboard = React.lazy(() => import('./pages/Dashboard'));

function App() {
  const { user, setUser, loading } = useAuthStore();
  const [supabaseError, setSupabaseError] = useState(!isSupabaseConfigured());

  useEffect(() => {
    if (!isSupabaseConfigured()) {
      return;
    }

    // Check active sessions and sets the user
    supabase.auth.getSession().then(({ data: { session } }) => {
      setUser(session?.user ?? null);
    });

    // Listen for changes on auth state
    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((_event, session) => {
      setUser(session?.user ?? null);
    });

    return () => subscription.unsubscribe();
  }, []);

  if (supabaseError) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center p-4">
        <div className="bg-gray-900 rounded-lg p-6 max-w-md w-full">
          <div className="flex items-center gap-3 text-red-500 mb-4">
            <AlertTriangle className="w-8 h-8" />
            <h2 className="text-xl font-bold">Configuration Error</h2>
          </div>
          <p className="text-white mb-4">
            Supabase is not properly configured. Please follow these steps:
          </p>
          <ol className="list-decimal list-inside text-gray-300 space-y-2 mb-6">
            <li>Click the "Connect to Supabase" button in the top right corner</li>
            <li>Create a new Supabase project or connect to an existing one</li>
            <li>The environment variables will be automatically configured</li>
            <li>Refresh the page after connecting</li>
          </ol>
          <div className="flex justify-center">
            <button 
              onClick={() => window.location.reload()}
              className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors"
            >
              Refresh Page
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-black flex items-center justify-center">
        <div className="animate-spin">
          <Dumbbell className="w-8 h-8 text-white" />
        </div>
      </div>
    );
  }

  return (
    <Router>
      <div className="min-h-screen bg-black text-white">
        <React.Suspense
          fallback={
            <div className="flex items-center justify-center min-h-screen">
              <div className="animate-spin">
                <Dumbbell className="w-8 h-8 text-white" />
              </div>
            </div>
          }
        >
          <Routes>
            <Route
              path="/login"
              element={!user ? <Login /> : <Navigate to="/dashboard" />}
            />
            <Route
              path="/dashboard/*"
              element={user ? <Dashboard /> : <Navigate to="/login" />}
            />
            <Route path="/" element={<Navigate to={user ? "/dashboard/my-routines" : "/login"} />} />
          </Routes>
        </React.Suspense>
      </div>
    </Router>
  );
}

export default App;