import React, { useState } from 'react';
import { Routes, Route, Link, useLocation } from 'react-router-dom';
import { useAuthStore } from '../store/authStore';
import { 
  Dumbbell,
  Users, 
  LogOut,
  UserCircle,
  Menu,
  X,
  ListChecks
} from 'lucide-react';
import Friends from './Friends';
import Profile from './Profile';
import MyRoutines from './MyRoutines';
import EditRoutine from './EditRoutine';

function Dashboard() {
  const { signOut } = useAuthStore();
  const location = useLocation();
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const isActive = (path: string) => {
    if (path === '/dashboard/my-routines') {
      return location.pathname === path || location.pathname.startsWith('/dashboard/edit-routine') 
        ? 'text-white bg-gray-800' 
        : 'text-gray-400 hover:text-white hover:bg-gray-800';
    }
    return location.pathname === path ? 'text-white bg-gray-800' : 'text-gray-400 hover:text-white hover:bg-gray-800';
  };

  const closeMenu = () => setIsMenuOpen(false);

  const NavLink = ({ to, icon: Icon, children }: { to: string; icon: React.ElementType; children: React.ReactNode }) => (
    <Link 
      to={to}
      onClick={closeMenu}
      className={`px-3 py-2 rounded-md text-sm font-medium transition-colors flex items-center gap-2 ${isActive(to)}`}
    >
      <Icon className="w-4 h-4" />
      <span>{children}</span>
    </Link>
  );

  return (
    <div className="min-h-screen bg-black">
      {/* Top Navigation */}
      <nav className="fixed top-0 left-0 right-0 bg-gray-900 border-b border-gray-800 z-50">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex items-center justify-between h-16">
            {/* Logo and Brand */}
            <div className="flex items-center gap-3">
              <Dumbbell className="w-8 h-8 text-indigo-500" />
              <span className="text-white font-semibold tracking-tight">GymTrackPro</span>
            </div>

            {/* Mobile menu button */}
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="md:hidden inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-white hover:bg-gray-800 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-white"
            >
              <span className="sr-only">Open main menu</span>
              {isMenuOpen ? (
                <X className="block h-6 w-6" />
              ) : (
                <Menu className="block h-6 w-6" />
              )}
            </button>

            {/* Desktop Navigation Links */}
            <div className="hidden md:flex items-center space-x-4">
              <NavLink to="/dashboard/my-routines" icon={ListChecks}>Mis Rutinas</NavLink>
              <NavLink to="/dashboard/friends" icon={Users}>Amigos</NavLink>
              <NavLink to="/dashboard/profile" icon={UserCircle}>Perfil</NavLink>
              
              <button
                onClick={() => signOut()}
                className="px-3 py-2 text-gray-400 hover:text-white hover:bg-gray-800 rounded-md text-sm font-medium transition-colors flex items-center gap-2"
                title="Cerrar sesión"
              >
                <LogOut className="w-4 h-4" />
                <span>Salir</span>
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Navigation Menu */}
        <div className={`md:hidden ${isMenuOpen ? 'block' : 'hidden'}`}>
          <div className="px-2 pt-2 pb-3 space-y-1 bg-gray-900 border-t border-gray-800">
            <NavLink to="/dashboard/my-routines" icon={ListChecks}>Mis Rutinas</NavLink>
            <NavLink to="/dashboard/friends" icon={Users}>Amigos</NavLink>
            <NavLink to="/dashboard/profile" icon={UserCircle}>Perfil</NavLink>
            
            <button
              onClick={() => {
                signOut();
                closeMenu();
              }}
              className="w-full px-3 py-2 text-gray-400 hover:text-white hover:bg-gray-800 rounded-md text-sm font-medium transition-colors flex items-center gap-2"
            >
              <LogOut className="w-4 h-4" />
              <span>Cerrar sesión</span>
            </button>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <div className="pt-22">
        <Routes>
          <Route index element={<MyRoutines />} />
          <Route path="my-routines" element={<MyRoutines />} />
          <Route path="edit-routine/:id" element={<EditRoutine />} />
          <Route path="friends" element={<Friends />} />
          <Route path="profile" element={<Profile />} />
        </Routes>
      </div>
    </div>
  );
}

export default Dashboard;