import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { useAuthStore } from '../store/authStore';
import { Search, UserPlus, UserMinus, Check, X, Bell } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { es } from 'date-fns/locale';

interface Profile {
  id: string;
  username: string;
  full_name: string | null;
  avatar_url: string | null;
}

interface FriendRequest {
  id: string;
  user_id: string;
  friend_id: string;
  status: 'pending' | 'accepted' | 'rejected';
  created_at: string;
  profile: Profile;
}

export default function Friends() {
  const { user } = useAuthStore();
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<Profile[]>([]);
  const [friends, setFriends] = useState<Profile[]>([]);
  const [pendingRequests, setPendingRequests] = useState<FriendRequest[]>([]);
  const [sentRequests, setSentRequests] = useState<FriendRequest[]>([]);
  const [userProfile, setUserProfile] = useState<Profile | null>(null);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  useEffect(() => {
    if (user) {
      fetchUserProfile();
      fetchFriends();
      fetchPendingRequests();
      fetchSentRequests();

      // Subscribe to realtime updates for friend requests
      const friendRequestsSubscription = supabase
        .channel('friend-requests')
        .on(
          'postgres_changes',
          {
            event: 'INSERT',
            schema: 'public',
            table: 'friendships',
            filter: `friend_id=eq.${user.id}`
          },
          (payload) => {
            console.log('New friend request received:', payload);
            fetchPendingRequests();
          }
        )
        .subscribe();

      return () => {
        friendRequestsSubscription.unsubscribe();
      };
    }
  }, [user]);

  async function fetchUserProfile() {
    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .eq('id', user?.id)
        .single();

      if (error) throw error;
      setUserProfile(data);
    } catch (error) {
      console.error('Error fetching profile:', error);
    }
  }

  async function fetchFriends() {
    try {
      const { data: friendships, error } = await supabase
        .from('friendships')
        .select(`
          id,
          profiles!friendships_friend_id_fkey (id, username, full_name, avatar_url)
        `)
        .eq('user_id', user?.id)
        .eq('status', 'accepted');

      if (error) throw error;
      setFriends(friendships?.map(f => f.profiles) || []);
    } catch (error) {
      console.error('Error fetching friends:', error);
    }
  }

  async function fetchPendingRequests() {
    try {
      const { data, error } = await supabase
        .from('friendships')
        .select(`
          id,
          user_id,
          friend_id,
          status,
          created_at,
          profiles!friendships_user_id_fkey (id, username, full_name, avatar_url)
        `)
        .eq('friend_id', user?.id)
        .eq('status', 'pending');

      if (error) throw error;
      setPendingRequests(data?.map(request => ({
        ...request,
        profile: request.profiles
      })) || []);
    } catch (error) {
      console.error('Error fetching pending requests:', error);
    }
  }

  async function fetchSentRequests() {
    try {
      const { data, error } = await supabase
        .from('friendships')
        .select(`
          id,
          user_id,
          friend_id,
          status,
          created_at,
          profiles!friendships_friend_id_fkey (id, username, full_name, avatar_url)
        `)
        .eq('user_id', user?.id)
        .eq('status', 'pending');

      if (error) throw error;
      setSentRequests(data?.map(request => ({
        ...request,
        profile: request.profiles
      })) || []);
    } catch (error) {
      console.error('Error fetching sent requests:', error);
    }
  }

  async function handleSearch() {
    if (!searchQuery.trim()) return;

    try {
      const { data, error } = await supabase
        .from('profiles')
        .select('*')
        .ilike('username', `%${searchQuery}%`)
        .neq('id', user?.id)
        .limit(5);

      if (error) throw error;
      setSearchResults(data || []);
    } catch (error) {
      console.error('Error searching users:', error);
    }
  }

  async function sendFriendRequest(friendId: string) {
    try {
      setError('');
      setSuccess('');

      // Check if request already exists
      const { data: existingRequests, error: checkError } = await supabase
        .from('friendships')
        .select('*')
        .or(`and(user_id.eq.${user?.id},friend_id.eq.${friendId}),and(user_id.eq.${friendId},friend_id.eq.${user?.id})`)
        .not('status', 'eq', 'rejected');

      if (checkError) throw checkError;

      if (existingRequests && existingRequests.length > 0) {
        setError('Ya existe una solicitud de amistad con este usuario');
        return;
      }

      const { error } = await supabase
        .from('friendships')
        .insert([
          {
            user_id: user?.id,
            friend_id: friendId,
            status: 'pending'
          }
        ]);

      if (error) throw error;

      setSuccess('Solicitud de amistad enviada');
      setSearchResults([]);
      setSearchQuery('');
      fetchSentRequests();
    } catch (error) {
      console.error('Error sending friend request:', error);
      setError('Error al enviar la solicitud de amistad');
    }
  }

  async function handleFriendRequest(requestId: string, accept: boolean) {
    try {
      setError('');
      setSuccess('');

      const { error } = await supabase
        .from('friendships')
        .update({ 
          status: accept ? 'accepted' : 'rejected',
          updated_at: new Date().toISOString()
        })
        .eq('id', requestId);

      if (error) throw error;

      setPendingRequests(requests => requests.filter(r => r.id !== requestId));
      if (accept) {
        fetchFriends();
        setSuccess('Solicitud de amistad aceptada');
      } else {
        setSuccess('Solicitud de amistad rechazada');
      }
    } catch (error) {
      console.error('Error handling friend request:', error);
      setError('Error al procesar la solicitud de amistad');
    }
  }

  async function removeFriend(friendId: string) {
    try {
      setError('');
      setSuccess('');

      const { error } = await supabase
        .from('friendships')
        .delete()
        .or(`and(user_id.eq.${user?.id},friend_id.eq.${friendId}),and(user_id.eq.${friendId},friend_id.eq.${user?.id})`);

      if (error) throw error;
      setFriends(friends => friends.filter(f => f.id !== friendId));
      setSuccess('Amigo eliminado');
    } catch (error) {
      console.error('Error removing friend:', error);
      setError('Error al eliminar amigo');
    }
  }

  return (
    <div className="max-w-4xl mx-auto px-4 pt-20">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-white mb-4">Amigos</h1>
        {userProfile && (
          <div className="bg-gray-800 p-4 rounded-lg mb-6">
            <h2 className="text-lg font-medium text-white mb-2">Tu ID de usuario</h2>
            <p className="text-gray-300 font-mono bg-gray-900 p-2 rounded">
              {userProfile.username}
            </p>
            <p className="text-sm text-gray-400 mt-2">
              Comparte este ID con tus amigos para que puedan encontrarte
            </p>
          </div>
        )}

        {(error || success) && (
          <div className={`p-4 rounded-lg mb-6 ${error ? 'bg-red-500' : 'bg-green-500'} text-white`}>
            {error || success}
          </div>
        )}
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <div>
          <div className="bg-gray-900 rounded-lg p-6">
            <h2 className="text-xl font-semibold text-white mb-4">Buscar Amigos</h2>
            <div className="flex gap-2 mb-4">
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
                placeholder="Buscar por ID de usuario"
                className="flex-1 px-3 py-2 bg-gray-800 border border-gray-700 rounded-md text-white"
              />
              <button
                onClick={handleSearch}
                className="p-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700"
              >
                <Search className="w-5 h-5" />
              </button>
            </div>

            {searchResults.length > 0 && (
              <div className="space-y-2">
                {searchResults.map((result) => (
                  <div
                    key={result.id}
                    className="flex items-center justify-between bg-gray-800 p-3 rounded-lg"
                  >
                    <div>
                      <p className="text-white font-medium">{result.username}</p>
                      {result.full_name && (
                        <p className="text-gray-400 text-sm">{result.full_name}</p>
                      )}
                    </div>
                    <button
                      onClick={() => sendFriendRequest(result.id)}
                      className="text-indigo-400 hover:text-indigo-300"
                    >
                      <UserPlus className="w-5 h-5" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {sentRequests.length > 0 && (
            <div className="mt-6 bg-gray-900 rounded-lg p-6">
              <h2 className="text-xl font-semibold text-white mb-4">
                Solicitudes Enviadas
              </h2>
              <div className="space-y-3">
                {sentRequests.map((request) => (
                  <div
                    key={request.id}
                    className="flex items-center justify-between bg-gray-800 p-3 rounded-lg"
                  >
                    <div>
                      <p className="text-white font-medium">
                        {request.profile.username}
                      </p>
                      <p className="text-sm text-gray-400">
                        Enviada {formatDistanceToNow(new Date(request.created_at), { locale: es, addSuffix: true })}
                      </p>
                    </div>
                    <span className="text-yellow-500 text-sm">Pendiente</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {pendingRequests.length > 0 && (
            <div className="mt-6 bg-gray-900 rounded-lg p-6">
              <div className="flex items-center gap-2 mb-4">
                <h2 className="text-xl font-semibold text-white">
                  Solicitudes Pendientes
                </h2>
                <div className="bg-red-500 text-white text-xs px-2 py-1 rounded-full">
                  {pendingRequests.length}
                </div>
              </div>
              <div className="space-y-3">
                {pendingRequests.map((request) => (
                  <div
                    key={request.id}
                    className="flex items-center justify-between bg-gray-800 p-3 rounded-lg"
                  >
                    <div>
                      <p className="text-white font-medium">
                        {request.profile.username}
                      </p>
                      <p className="text-sm text-gray-400">
                        Recibida {formatDistanceToNow(new Date(request.created_at), { locale: es, addSuffix: true })}
                      </p>
                    </div>
                    <div className="flex gap-2">
                      <button
                        onClick={() => handleFriendRequest(request.id, true)}
                        className="text-green-500 hover:text-green-400"
                        title="Aceptar solicitud"
                      >
                        <Check className="w-5 h-5" />
                      </button>
                      <button
                        onClick={() => handleFriendRequest(request.id, false)}
                        className="text-red-500 hover:text-red-400"
                        title="Rechazar solicitud"
                      >
                        <X className="w-5 h-5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        <div className="bg-gray-900 rounded-lg p-6">
          <h2 className="text-xl font-semibold text-white mb-4">
            Mis Amigos ({friends.length})
          </h2>
          {friends.length === 0 ? (
            <p className="text-gray-400">Aún no tienes amigos añadidos</p>
          ) : (
            <div className="space-y-3">
              {friends.map((friend) => (
                <div
                  key={friend.id}
                  className="flex items-center justify-between bg-gray-800 p-3 rounded-lg"
                >
                  <div className="flex items-center gap-3">
                    <img
                      src={friend.avatar_url || `https://ui-avatars.com/api/?name=${encodeURIComponent(friend.full_name || friend.username)}&background=random`}
                      alt={friend.username}
                      className="w-10 h-10 rounded-full"
                    />
                    <div>
                      <p className="text-white font-medium">{friend.username}</p>
                      {friend.full_name && (
                        <p className="text-gray-400 text-sm">{friend.full_name}</p>
                      )}
                    </div>
                  </div>
                  <button
                    onClick={() => removeFriend(friend.id)}
                    className="text-red-500 hover:text-red-400"
                    title="Eliminar amigo"
                  >
                    <UserMinus className="w-5 h-5" />
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}