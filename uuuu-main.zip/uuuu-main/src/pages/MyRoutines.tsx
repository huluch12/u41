import React, { useState, useEffect, useMemo } from 'react';
import { supabase } from '../lib/supabase';
import { useAuthStore } from '../store/authStore';
import { 
  Plus, 
  Edit2, 
  Trash2, 
  Copy, 
  Star, 
  Search, 
  Filter, 
  ChevronDown, 
  ChevronUp, 
  Calendar,
  Loader2,
  ArrowUpDown,
  AlertCircle,
  X
} from 'lucide-react';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';
import CreateRoutine from './CreateRoutine';

interface Routine {
  id: string;
  name: string;
  description: string | null;
  created_at: string;
  is_favorite: boolean;
  exercises: RoutineExercise[];
}

interface RoutineExercise {
  id: string;
  name: string;
  sets: number;
  reps: number;
  weight: number;
  notes: string | null;
  order_index: number;
}

type SortField = 'name' | 'created_at' | 'is_favorite';
type SortOrder = 'asc' | 'desc';

export default function MyRoutines() {
  const { user } = useAuthStore();
  const [routines, setRoutines] = useState<Routine[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [expandedRoutine, setExpandedRoutine] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [sortField, setSortField] = useState<SortField>('created_at');
  const [sortOrder, setSortOrder] = useState<SortOrder>('desc');
  const [showFavorites, setShowFavorites] = useState(false);
  const [editingRoutine, setEditingRoutine] = useState<Routine | null>(null);
  const [confirmDelete, setConfirmDelete] = useState<string | null>(null);
  const [savingFavorite, setSavingFavorite] = useState<string | null>(null);
  const [isCreatingRoutine, setIsCreatingRoutine] = useState(false);

  useEffect(() => {
    if (user) {
      fetchRoutines();
    }
  }, [user]);

  const fetchRoutines = async () => {
    try {
      setLoading(true);
      setError('');

      const { data, error } = await supabase
        .from('routines')
        .select(`
          id,
          name,
          description,
          created_at,
          is_favorite,
          routine_exercises (
            id,
            name,
            sets,
            reps,
            weight,
            notes,
            order_index
          )
        `)
        .eq('user_id', user?.id)
        .order('created_at', { ascending: false });

      if (error) throw error;

      // Sort exercises by order_index
      const routinesWithSortedExercises = data?.map(routine => ({
        ...routine,
        exercises: (routine.routine_exercises || []).sort((a, b) => a.order_index - b.order_index)
      })) || [];

      setRoutines(routinesWithSortedExercises);
    } catch (error) {
      console.error('Error fetching routines:', error);
      setError('Error al cargar las rutinas');
    } finally {
      setLoading(false);
    }
  };

  const handleToggleFavorite = async (routineId: string) => {
    try {
      setSavingFavorite(routineId);
      const routine = routines.find(r => r.id === routineId);
      if (!routine) return;

      const newValue = !routine.is_favorite;

      const { error } = await supabase
        .from('routines')
        .update({ is_favorite: newValue })
        .eq('id', routineId);

      if (error) throw error;

      // Update local state
      setRoutines(routines.map(r => 
        r.id === routineId ? { ...r, is_favorite: newValue } : r
      ));

      setSuccess(`Rutina ${newValue ? 'marcada como favorita' : 'desmarcada como favorita'}`);
      setTimeout(() => setSuccess(''), 2000);
    } catch (error) {
      console.error('Error toggling favorite:', error);
      setError('Error al actualizar favorito');
      setTimeout(() => setError(''), 3000);
    } finally {
      setSavingFavorite(null);
    }
  };

  const handleDeleteRoutine = async (routineId: string) => {
    try {
      setLoading(true);
      setError('');

      const { error } = await supabase
        .from('routines')
        .delete()
        .eq('id', routineId);

      if (error) throw error;

      // Update local state
      setRoutines(routines.filter(r => r.id !== routineId));
      setSuccess('Rutina eliminada correctamente');
      setTimeout(() => setSuccess(''), 2000);
    } catch (error) {
      console.error('Error deleting routine:', error);
      setError('Error al eliminar la rutina');
      setTimeout(() => setError(''), 3000);
    } finally {
      setLoading(false);
      setConfirmDelete(null);
    }
  };

  const handleDuplicateRoutine = async (routineId: string) => {
    try {
      setLoading(true);
      setError('');

      // Find the routine to duplicate
      const routineToDuplicate = routines.find(r => r.id === routineId);
      if (!routineToDuplicate) {
        throw new Error('Rutina no encontrada');
      }

      // Create a new routine
      const { data: newRoutine, error: routineError } = await supabase
        .from('routines')
        .insert([{
          name: `${routineToDuplicate.name} (Copia)`,
          description: routineToDuplicate.description,
          user_id: user?.id,
          is_favorite: false
        }])
        .select()
        .single();

      if (routineError) throw routineError;

      // Duplicate exercises
      for (const exercise of routineToDuplicate.exercises) {
        const { error: exerciseError } = await supabase
          .from('routine_exercises')
          .insert([{
            routine_id: newRoutine.id,
            name: exercise.name,
            sets: exercise.sets,
            reps: exercise.reps,
            weight: exercise.weight,
            notes: exercise.notes,
            order_index: exercise.order_index
          }]);

        if (exerciseError) throw exerciseError;
      }

      // Refresh routines
      await fetchRoutines();
      setSuccess('Rutina duplicada correctamente');
      setTimeout(() => setSuccess(''), 2000);
    } catch (error) {
      console.error('Error duplicating routine:', error);
      setError('Error al duplicar la rutina');
      setTimeout(() => setError(''), 3000);
    } finally {
      setLoading(false);
    }
  };

  const toggleSort = (field: SortField) => {
    if (sortField === field) {
      setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortOrder('asc');
    }
  };

  const filteredAndSortedRoutines = useMemo(() => {
    // First filter by search query and favorites
    let filtered = routines.filter(routine => {
      const matchesSearch = searchQuery === '' || 
        routine.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (routine.description && routine.description.toLowerCase().includes(searchQuery.toLowerCase()));
      
      const matchesFavorite = !showFavorites || routine.is_favorite;
      
      return matchesSearch && matchesFavorite;
    });

    // Then sort
    return filtered.sort((a, b) => {
      if (sortField === 'name') {
        return sortOrder === 'asc' 
          ? a.name.localeCompare(b.name)
          : b.name.localeCompare(a.name);
      } else if (sortField === 'created_at') {
        return sortOrder === 'asc'
          ? new Date(a.created_at).getTime() - new Date(b.created_at).getTime()
          : new Date(b.created_at).getTime() - new Date(a.created_at).getTime();
      } else if (sortField === 'is_favorite') {
        return sortOrder === 'asc'
          ? (a.is_favorite === b.is_favorite ? 0 : a.is_favorite ? -1 : 1)
          : (a.is_favorite === b.is_favorite ? 0 : a.is_favorite ? 1 : -1);
      }
      return 0;
    });
  }, [routines, searchQuery, sortField, sortOrder, showFavorites]);

  const getSortIcon = (field: SortField) => {
    if (sortField !== field) return <ArrowUpDown className="w-4 h-4 text-gray-400" />;
    return sortOrder === 'asc' 
      ? <ChevronUp className="w-4 h-4 text-indigo-400" />
      : <ChevronDown className="w-4 h-4 text-indigo-400" />;
  };

  const handleRoutineCreated = () => {
    setIsCreatingRoutine(false);
    fetchRoutines();
  };

  if (loading && routines.length === 0) {
    return (
      <div className="flex items-center justify-center min-h-[50vh]">
        <Loader2 className="w-8 h-8 text-white animate-spin" />
      </div>
    );
  }

  if (isCreatingRoutine) {
    return (
      <div className="max-w-4xl mx-auto px-4 pt-20 pb-16">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-3xl font-bold text-white">Nueva Rutina</h1>
          <button
            onClick={() => setIsCreatingRoutine(false)}
            className="text-gray-400 hover:text-white transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>
        <CreateRoutine onRoutineCreated={handleRoutineCreated} />
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto px-4 pt-20 pb-16">
      <div className="flex flex-col md:flex-row md:items-center justify-between mb-6 gap-4">
        <h1 className="text-3xl font-bold text-white">Mis Rutinas</h1>
        <button 
          onClick={() => setIsCreatingRoutine(true)}
          className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors"
        >
          <Plus className="w-5 h-5" />
          <span>Nueva Rutina</span>
        </button>
      </div>

      {(error || success) && (
        <div className={`p-4 rounded-lg mb-6 ${error ? 'bg-red-500' : 'bg-green-500'} text-white`}>
          {error || success}
        </div>
      )}

      {/* Filters and Search */}
      <div className="bg-gray-900 rounded-xl p-6 mb-8">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
              <input
                type="text"
                placeholder="Buscar rutinas..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => setShowFavorites(!showFavorites)}
              className={`px-4 py-2 rounded-lg border ${
                showFavorites 
                  ? 'bg-indigo-600 border-indigo-500 text-white' 
                  : 'bg-gray-800 border-gray-700 text-gray-300'
              } transition-colors`}
            >
              <Star className={`w-5 h-5 ${showFavorites ? 'text-yellow-300 fill-yellow-300' : ''}`} />
            </button>
          </div>
        </div>

        <div className="mt-4 flex flex-wrap gap-2">
          <button
            onClick={() => toggleSort('name')}
            className={`flex items-center gap-1 px-3 py-1.5 rounded-lg ${
              sortField === 'name' ? 'bg-indigo-600 text-white' : 'bg-gray-800 text-gray-300'
            }`}
          >
            <span>Nombre</span>
            {getSortIcon('name')}
          </button>
          <button
            onClick={() => toggleSort('created_at')}
            className={`flex items-center gap-1 px-3 py-1.5 rounded-lg ${
              sortField === 'created_at' ? 'bg-indigo-600 text-white' : 'bg-gray-800 text-gray-300'
            }`}
          >
            <span>Fecha</span>
            {getSortIcon('created_at')}
          </button>
          <button
            onClick={() => toggleSort('is_favorite')}
            className={`flex items-center gap-1 px-3 py-1.5 rounded-lg ${
              sortField === 'is_favorite' ? 'bg-indigo-600 text-white' : 'bg-gray-800 text-gray-300'
            }`}
          >
            <span>Favoritos</span>
            {getSortIcon('is_favorite')}
          </button>
        </div>
      </div>

      {/* Routines List */}
      {filteredAndSortedRoutines.length === 0 ? (
        <div className="bg-gray-900 rounded-xl p-8 text-center">
          <div className="flex justify-center mb-4">
            <Calendar className="w-12 h-12 text-gray-600" />
          </div>
          <h3 className="text-xl font-medium text-white mb-2">No hay rutinas</h3>
          <p className="text-gray-400 mb-6">
            {searchQuery || showFavorites 
              ? 'No se encontraron rutinas con los filtros actuales' 
              : 'Aún no has creado ninguna rutina'}
          </p>
          <button 
            onClick={() => setIsCreatingRoutine(true)}
            className="inline-flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors"
          >
            <Plus className="w-5 h-5" />
            <span>Crear tu primera rutina</span>
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {filteredAndSortedRoutines.map((routine) => (
            <div 
              key={routine.id} 
              className="bg-gray-900 rounded-xl overflow-hidden border border-gray-800 hover:border-gray-700 transition-colors"
            >
              <div className="p-6">
                <div className="flex justify-between items-start mb-2">
                  <h3 className="text-xl font-semibold text-white">{routine.name}</h3>
                  <div className="flex gap-1">
                    <button
                      onClick={() => handleToggleFavorite(routine.id)}
                      disabled={savingFavorite === routine.id}
                      className="text-gray-400 hover:text-yellow-300 transition-colors p-1"
                      title={routine.is_favorite ? "Quitar de favoritos" : "Añadir a favoritos"}
                    >
                      {savingFavorite === routine.id ? (
                        <Loader2 className="w-5 h-5 animate-spin" />
                      ) : (
                        <Star className={`w-5 h-5 ${routine.is_favorite ? 'text-yellow-300 fill-yellow-300' : ''}`} />
                      )}
                    </button>
                    <button
                      onClick={() => handleDuplicateRoutine(routine.id)}
                      className="text-gray-400 hover:text-indigo-400 transition-colors p-1"
                      title="Duplicar rutina"
                    >
                      <Copy className="w-5 h-5" />
                    </button>
                    <a
                      href={`/dashboard/edit-routine/${routine.id}`}
                      className="text-gray-400 hover:text-white transition-colors p-1"
                      title="Editar rutina"
                    >
                      <Edit2 className="w-5 h-5" />
                    </a>
                    <button
                      onClick={() => setConfirmDelete(routine.id)}
                      className="text-gray-400 hover:text-red-500 transition-colors p-1"
                      title="Eliminar rutina"
                    >
                      <Trash2 className="w-5 h-5" />
                    </button>
                  </div>
                </div>
                
                {routine.description && (
                  <p className="text-gray-400 mb-4 text-sm">{routine.description}</p>
                )}
                
                <div className="flex justify-between items-center text-xs text-gray-500 mb-4">
                  <span>
                    Creada: {format(new Date(routine.created_at), 'dd MMM yyyy', { locale: es })}
                  </span>
                  <span>{routine.exercises.length} ejercicios</span>
                </div>
                
                <button
                  onClick={() => setExpandedRoutine(expandedRoutine === routine.id ? null : routine.id)}
                  className="flex items-center gap-2 text-indigo-400 hover:text-indigo-300 transition-colors text-sm"
                >
                  {expandedRoutine === routine.id ? (
                    <>
                      <ChevronUp className="w-4 h-4" />
                      <span>Ocultar detalles</span>
                    </>
                  ) : (
                    <>
                      <ChevronDown className="w-4 h-4" />
                      <span>Ver detalles</span>
                    </>
                  )}
                </button>
              </div>
              
              {expandedRoutine === routine.id && (
                <div className="border-t border-gray-800 p-6 bg-gray-800">
                  <h4 className="text-lg font-medium text-white mb-4">Ejercicios</h4>
                  <div className="space-y-4">
                    {routine.exercises.map((exercise) => (
                      <div key={exercise.id} className="bg-gray-900 p-4 rounded-lg">
                        <h5 className="font-medium text-white mb-2">{exercise.name}</h5>
                        <div className="grid grid-cols-3 gap-2 text-sm text-gray-400 mb-2">
                          <div>
                            <span className="text-gray-500">Series:</span> {exercise.sets}
                          </div>
                          <div>
                            <span className="text-gray-500">Reps:</span> {exercise.reps}
                          </div>
                          <div>
                            <span className="text-gray-500">Peso:</span> {exercise.weight}kg
                          </div>
                        </div>
                        {exercise.notes && (
                          <p className="text-xs text-gray-500 mt-2">{exercise.notes}</p>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}
              
              {/* Delete Confirmation */}
              {confirmDelete === routine.id && (
                <div className="border-t border-gray-800 p-6 bg-gray-800">
                  <div className="flex items-start gap-3 mb-4">
                    <AlertCircle className="w-6 h-6 text-red-500 flex-shrink-0" />
                    <div>
                      <h4 className="text-white font-medium mb-1">¿Eliminar esta rutina?</h4>
                      <p className="text-gray-400 text-sm">Esta acción no se puede deshacer.</p>
                    </div>
                  </div>
                  <div className="flex justify-end gap-3">
                    <button
                      onClick={() => setConfirmDelete(null)}
                      className="px-4 py-2 text-gray-300 hover:text-white transition-colors"
                    >
                      Cancelar
                    </button>
                    <button
                      onClick={() => handleDeleteRoutine(routine.id)}
                      className="px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors"
                    >
                      Eliminar
                    </button>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}