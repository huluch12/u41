import React, { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { useAuthStore } from '../store/authStore';
import { 
  Plus, 
  Trash2, 
  Save, 
  Calendar, 
  Share2, 
  Info, 
  X, 
  ChevronDown, 
  ChevronUp,
  Loader2
} from 'lucide-react';

interface Exercise {
  id: string;
  name: string;
  sets: number;
  reps: number;
  weight: number;
  notes: string;
}

interface Friend {
  id: string;
  username: string;
  full_name: string | null;
  avatar_url: string | null;
}

interface ScheduleDay {
  day: number;
  enabled: boolean;
  time: string;
}

interface SeriesDetail {
  reps: number;
  weight: number;
}

interface CreateRoutineProps {
  onRoutineCreated: () => void;
}

const DAYS_OF_WEEK = [
  'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado', 'Domingo'
];

const DEFAULT_EXERCISE: Exercise = {
  id: crypto.randomUUID(),
  name: '',
  sets: 3,
  reps: 10,
  weight: 0,
  notes: ''
};

export default function CreateRoutine({ onRoutineCreated }: CreateRoutineProps) {
  const { user } = useAuthStore();
  const [routineName, setRoutineName] = useState('');
  const [exercises, setExercises] = useState<Exercise[]>([]);
  const [friends, setFriends] = useState<Friend[]>([]);
  const [selectedFriends, setSelectedFriends] = useState<string[]>([]);
  const [showFriendSelector, setShowFriendSelector] = useState(false);
  const [showScheduler, setShowScheduler] = useState(false);
  const [schedule, setSchedule] = useState<ScheduleDay[]>(
    DAYS_OF_WEEK.map((_, index) => ({
      day: index,
      enabled: false,
      time: '08:00'
    }))
  );
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [expandedExercise, setExpandedExercise] = useState<string | null>(null);
  const [seriesDetails, setSeriesDetails] = useState<Record<string, SeriesDetail[]>>({});
  const [numSeriesToGenerate, setNumSeriesToGenerate] = useState<Record<string, number>>({});

  useEffect(() => {
    if (user) {
      fetchFriends();
    }
  }, [user]);

  const fetchFriends = async () => {
    try {
      const { data: friendships, error } = await supabase
        .from('friendships')
        .select(`
          id,
          profiles!friendships_friend_id_fkey (id, username, full_name, avatar_url)
        `)
        .eq('user_id', user?.id)
        .eq('status', 'accepted');

      if (error) throw error;
      setFriends(friendships?.map(f => f.profiles) || []);
    } catch (error) {
      console.error('Error fetching friends:', error);
    }
  };

  const addExercise = () => {
    const newExerciseId = crypto.randomUUID();
    setExercises([...exercises, { ...DEFAULT_EXERCISE, id: newExerciseId }]);
    
    // Initialize series details for the new exercise
    setSeriesDetails(prev => ({
      ...prev,
      [newExerciseId]: Array(DEFAULT_EXERCISE.sets).fill({
        reps: DEFAULT_EXERCISE.reps,
        weight: DEFAULT_EXERCISE.weight
      })
    }));
    
    // Initialize number of series to generate
    setNumSeriesToGenerate(prev => ({
      ...prev,
      [newExerciseId]: DEFAULT_EXERCISE.sets
    }));
  };

  const updateExercise = (id: string, field: keyof Exercise, value: any) => {
    setExercises(exercises.map(ex => 
      ex.id === id ? { ...ex, [field]: value } : ex
    ));
    
    // If updating sets, update series details
    if (field === 'sets') {
      const currentDetails = seriesDetails[id] || [];
      const newValue = parseInt(value) || 0;
      
      if (newValue > currentDetails.length) {
        // Add new series with default values
        const exercise = exercises.find(ex => ex.id === id);
        const defaultReps = exercise?.reps || 10;
        const defaultWeight = exercise?.weight || 0;
        
        setSeriesDetails(prev => ({
          ...prev,
          [id]: [
            ...currentDetails,
            ...Array(newValue - currentDetails.length).fill({
              reps: defaultReps,
              weight: defaultWeight
            })
          ]
        }));
      } else if (newValue < currentDetails.length) {
        // Remove excess series
        setSeriesDetails(prev => ({
          ...prev,
          [id]: currentDetails.slice(0, newValue)
        }));
      }
    }
  };

  const removeExercise = (id: string) => {
    setExercises(exercises.filter(ex => ex.id !== id));
    
    // Clean up series details for the removed exercise
    setSeriesDetails(prev => {
      const newDetails = { ...prev };
      delete newDetails[id];
      return newDetails;
    });
    
    // Clean up number of series to generate
    setNumSeriesToGenerate(prev => {
      const newValues = { ...prev };
      delete newValues[id];
      return newValues;
    });
  };

  const toggleFriendSelection = (friendId: string) => {
    setSelectedFriends(prev => 
      prev.includes(friendId)
        ? prev.filter(id => id !== friendId)
        : [...prev, friendId]
    );
  };

  const toggleScheduleDay = (dayIndex: number) => {
    setSchedule(schedule.map((day, index) => 
      index === dayIndex ? { ...day, enabled: !day.enabled } : day
    ));
  };

  const updateScheduleTime = (dayIndex: number, time: string) => {
    setSchedule(schedule.map((day, index) => 
      index === dayIndex ? { ...day, time } : day
    ));
  };

  const validateForm = (): boolean => {
    if (!routineName.trim()) {
      setError('Por favor, ingresa un nombre para la rutina');
      return false;
    }

    if (exercises.length === 0) {
      setError('Debes agregar al menos un ejercicio');
      return false;
    }

    for (const exercise of exercises) {
      if (!exercise.name.trim()) {
        setError('Todos los ejercicios deben tener un nombre');
        return false;
      }
      if (exercise.sets <= 0) {
        setError(`El número de series para ${exercise.name} debe ser mayor a 0`);
        return false;
      }
      if (exercise.reps <= 0) {
        setError(`El número de repeticiones para ${exercise.name} debe ser mayor a 0`);
        return false;
      }
      if (exercise.weight < 0) {
        setError(`El peso para ${exercise.name} no puede ser negativo`);
        return false;
      }
    }

    return true;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) return;
    
    try {
      setSaving(true);
      setError('');
      setSuccess('');

      // Create routine in database
      const { data: routine, error: routineError } = await supabase
        .from('routines')
        .insert([{
          name: routineName,
          user_id: user?.id,
          schedule: schedule.filter(day => day.enabled)
        }])
        .select()
        .single();

      if (routineError) throw routineError;

      // Add exercises
      for (const exercise of exercises) {
        const { error: exerciseError } = await supabase
          .from('routine_exercises')
          .insert([{
            routine_id: routine.id,
            name: exercise.name,
            sets: exercise.sets,
            reps: exercise.reps,
            weight: exercise.weight,
            notes: exercise.notes
          }]);

        if (exerciseError) throw exerciseError;
      }

      // Share with friends if selected
      if (selectedFriends.length > 0) {
        const shares = selectedFriends.map(friendId => ({
          routine_id: routine.id,
          user_id: user?.id,
          friend_id: friendId
        }));

        const { error: shareError } = await supabase
          .from('routine_shares')
          .insert(shares);

        if (shareError) throw shareError;
      }

      setSuccess('¡Rutina creada exitosamente!');
      
      // Reset form
      setRoutineName('');
      setExercises([]);
      setSelectedFriends([]);
      setSchedule(DAYS_OF_WEEK.map((_, index) => ({
        day: index,
        enabled: false,
        time: '08:00'
      })));
      setSeriesDetails({});
      setNumSeriesToGenerate({});
      
      // Notify parent component that routine was created
      setTimeout(() => {
        onRoutineCreated();
      }, 1500);
      
    } catch (error) {
      console.error('Error saving routine:', error);
      setError('Error al guardar la rutina. Por favor, intenta de nuevo.');
    } finally {
      setSaving(false);
    }
  };

  const toggleExerciseExpansion = (id: string) => {
    setExpandedExercise(expandedExercise === id ? null : id);
  };

  const updateSeriesDetail = (exerciseId: string, seriesIndex: number, field: keyof SeriesDetail, value: number) => {
    setSeriesDetails(prev => {
      const exerciseDetails = [...(prev[exerciseId] || [])];
      exerciseDetails[seriesIndex] = {
        ...exerciseDetails[seriesIndex],
        [field]: value
      };
      return {
        ...prev,
        [exerciseId]: exerciseDetails
      };
    });
  };

  const generateSeries = (exerciseId: string) => {
    const exercise = exercises.find(ex => ex.id === exerciseId);
    if (!exercise) return;
    
    const numSeries = numSeriesToGenerate[exerciseId] || exercise.sets;
    if (numSeries <= 0) return;
    
    // Update exercise sets count
    updateExercise(exerciseId, 'sets', numSeries);
    
    // Generate series details
    const newSeriesDetails = Array(numSeries).fill({
      reps: exercise.reps,
      weight: exercise.weight
    });
    
    setSeriesDetails(prev => ({
      ...prev,
      [exerciseId]: newSeriesDetails
    }));
  };

  return (
    <div>
      {(error || success) && (
        <div className={`p-4 rounded-lg mb-6 ${error ? 'bg-red-500' : 'bg-green-500'} text-white`}>
          {error || success}
        </div>
      )}

      <form onSubmit={handleSubmit} className="space-y-8">
        {/* Routine Name */}
        <div className="bg-gray-900 rounded-xl p-6">
          <label className="block text-lg font-medium text-white mb-2">
            Nombre de la Rutina
          </label>
          <input
            type="text"
            value={routineName}
            onChange={(e) => setRoutineName(e.target.value)}
            placeholder="Ej: Rutina de Fuerza, Día de Piernas, etc."
            className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-lg text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
            required
          />
        </div>

        {/* Exercises Section */}
        <div className="bg-gray-900 rounded-xl p-6">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-semibold text-white">Ejercicios</h2>
            <button
              type="button"
              onClick={addExercise}
              className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors"
            >
              <Plus className="w-5 h-5" />
              Agregar Ejercicio
            </button>
          </div>

          {exercises.length === 0 ? (
            <div className="text-center py-10 text-gray-400">
              <p className="mb-4">No hay ejercicios agregados</p>
              <button
                type="button"
                onClick={addExercise}
                className="px-4 py-2 bg-gray-800 text-white rounded-lg hover:bg-gray-700 transition-colors"
              >
                Agregar tu primer ejercicio
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              {exercises.map((exercise) => (
                <div key={exercise.id} className="bg-gray-800 rounded-lg overflow-hidden">
                  <div 
                    className="flex items-center justify-between p-4 cursor-pointer hover:bg-gray-700 transition-colors"
                    onClick={() => toggleExerciseExpansion(exercise.id)}
                  >
                    <div className="flex items-center gap-3">
                      {expandedExercise === exercise.id ? (
                        <ChevronUp className="w-5 h-5 text-gray-400" />
                      ) : (
                        <ChevronDown className="w-5 h-5 text-gray-400" />
                      )}
                      <h3 className="font-medium text-white">
                        {exercise.name || "Nuevo Ejercicio"}
                      </h3>
                    </div>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        removeExercise(exercise.id);
                      }}
                      className="text-gray-400 hover:text-red-500 transition-colors"
                    >
                      <Trash2 className="w-5 h-5" />
                    </button>
                  </div>

                  <div className={`px-4 pb-4 ${expandedExercise === exercise.id ? 'block' : 'hidden'}`}>
                    <div className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-300 mb-1">
                          Nombre del Ejercicio
                        </label>
                        <input
                          type="text"
                          value={exercise.name}
                          onChange={(e) => updateExercise(exercise.id, 'name', e.target.value)}
                          placeholder="Ej: Press de Banca, Sentadillas, etc."
                          className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-md text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                          required
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-gray-300 mb-1">
                          Series
                        </label>
                        <div className="flex gap-2 items-center">
                          <input
                            type="number"
                            min="1"
                            value={numSeriesToGenerate[exercise.id] || exercise.sets}
                            onChange={(e) => setNumSeriesToGenerate({
                              ...numSeriesToGenerate,
                              [exercise.id]: parseInt(e.target.value) || 1
                            })}
                            className="w-20 px-3 py-2 bg-gray-700 border border-gray-600 rounded-md text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                          />
                          <button
                            type="button"
                            onClick={() => generateSeries(exercise.id)}
                            className="px-3 py-2 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 transition-colors"
                          >
                            Generar Series
                          </button>
                        </div>
                      </div>

                      {/* Individual Series Details */}
                      {seriesDetails[exercise.id] && seriesDetails[exercise.id].length > 0 && (
                        <div className="space-y-3 mt-4">
                          <h4 className="text-sm font-medium text-gray-300">Detalles de Series</h4>
                          {seriesDetails[exercise.id].map((series, index) => (
                            <div key={index} className="grid grid-cols-2 gap-4 p-3 bg-gray-700 rounded-md">
                              <div>
                                <label className="block text-xs font-medium text-gray-400 mb-1">
                                  Repeticiones (Serie {index + 1})
                                </label>
                                <input
                                  type="number"
                                  min="1"
                                  value={series.reps}
                                  onChange={(e) => updateSeriesDetail(
                                    exercise.id,
                                    index,
                                    'reps',
                                    parseInt(e.target.value) || 0
                                  )}
                                  className="w-full px-3 py-2 bg-gray-600 border border-gray-500 rounded-md text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                                />
                              </div>
                              <div>
                                <label className="block text-xs font-medium text-gray-400 mb-1">
                                  Peso (kg) (Serie {index + 1})
                                </label>
                                <input
                                  type="number"
                                  min="0"
                                  step="0.5"
                                  value={series.weight}
                                  onChange={(e) => updateSeriesDetail( exercise.id,
                                    index,
                                    'weight',
                                    parseFloat(e.target.value) || 0
                                  )}
                                  className="w-full px-3 py-2 bg-gray-600 border border-gray-500 rounded-md text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                                />
                              </div>
                            </div>
                          ))}
                        </div>
                      )}

                      <div>
                        <label className="block text-sm font-medium text-gray-300 mb-1">
                          Notas o Instrucciones
                        </label>
                        <textarea
                          value={exercise.notes}
                          onChange={(e) => updateExercise(exercise.id, 'notes', e.target.value)}
                          placeholder="Instrucciones especiales, técnica, etc."
                          className="w-full px-3 py-2 bg-gray-700 border border-gray-600 rounded-md text-white focus:outline-none focus:ring-2 focus:ring-indigo-500"
                          rows={3}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Schedule Section */}
        <div className="bg-gray-900 rounded-xl p-6">
          <button
            type="button"
            onClick={() => setShowScheduler(!showScheduler)}
            className="flex items-center justify-between w-full text-left"
          >
            <div className="flex items-center gap-2">
              <Calendar className="w-5 h-5 text-indigo-400" />
              <h2 className="text-xl font-semibold text-white">Programar Rutina</h2>
            </div>
            <ChevronDown className={`w-5 h-5 text-gray-400 transition-transform ${showScheduler ? 'rotate-180' : ''}`} />
          </button>

          {showScheduler && (
            <div className="mt-4 space-y-4">
              <p className="text-gray-400 text-sm">
                Selecciona los días y horarios para programar recordatorios para esta rutina.
              </p>

              <div className="space-y-2">
                {schedule.map((day, index) => (
                  <div key={index} className="flex items-center gap-4 p-2 rounded-lg hover:bg-gray-800">
                    <input
                      type="checkbox"
                      id={`day-${index}`}
                      checked={day.enabled}
                      onChange={() => toggleScheduleDay(index)}
                      className="w-5 h-5 rounded text-indigo-600 bg-gray-700 border-gray-600 focus:ring-indigo-500 focus:ring-offset-gray-900"
                    />
                    <label htmlFor={`day-${index}`} className="flex-1 text-white">
                      {DAYS_OF_WEEK[index]}
                    </label>
                    <input
                      type="time"
                      value={day.time}
                      onChange={(e) => updateScheduleTime(index, e.target.value)}
                      disabled={!day.enabled}
                      className="px-3 py-2 bg-gray-700 border border-gray-600 rounded-md text-white focus:outline-none focus:ring-2 focus:ring-indigo-500 disabled:opacity-50"
                    />
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Share Section */}
        <div className="bg-gray-900 rounded-xl p-6">
          <button
            type="button"
            onClick={() => setShowFriendSelector(!showFriendSelector)}
            className="flex items-center justify-between w-full text-left"
          >
            <div className="flex items-center gap-2">
              <Share2 className="w-5 h-5 text-indigo-400" />
              <h2 className="text-xl font-semibold text-white">Compartir Rutina</h2>
            </div>
            <ChevronDown className={`w-5 h-5 text-gray-400 transition-transform ${showFriendSelector ? 'rotate-180' : ''}`} />
          </button>

          {showFriendSelector && (
            <div className="mt-4 space-y-4">
              {friends.length === 0 ? (
                <p className="text-gray-400">
                  No tienes amigos para compartir. Agrega amigos desde la sección "Amigos".
                </p>
              ) : (
                <>
                  <p className="text-gray-400 text-sm">
                    Selecciona los amigos con los que quieres compartir esta rutina.
                  </p>
                  <div className="space-y-2 max-h-60 overflow-y-auto pr-2">
                    {friends.map((friend) => (
                      <div key={friend.id} className="flex items-center gap-3 p-2 rounded-lg hover:bg-gray-800">
                        <input
                          type="checkbox"
                          id={`friend-${friend.id}`}
                          checked={selectedFriends.includes(friend.id)}
                          onChange={() => toggleFriendSelection(friend.id)}
                          className="w-5 h-5 rounded text-indigo-600 bg-gray-700 border-gray-600 focus:ring-indigo-500 focus:ring-offset-gray-900"
                        />
                        <label htmlFor={`friend-${friend.id}`} className="flex items-center gap-3 cursor-pointer flex-1">
                          <img
                            src={friend.avatar_url || `https://ui-avatars.com/api/?name=${encodeURIComponent(friend.full_name || friend.username)}&background=random`}
                            alt={friend.username}
                            className="w-8 h-8 rounded-full"
                          />
                          <span className="text-white">{friend.username}</span>
                        </label>
                      </div>
                    ))}
                  </div>
                </>
              )}
            </div>
          )}
        </div>

        {/* Submit Button */}
        <div className="flex justify-end">
          <button
            type="submit"
            disabled={saving}
            className="flex items-center gap-2 px-6 py-3 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors disabled:opacity-70 disabled:cursor-not-allowed"
          >
            {saving ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                <span>Guardando...</span>
              </>
            ) : (
              <>
                <Save className="w-5 h-5" />
                <span>Guardar Rutina</span>
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
}