import React, { useState } from 'react';
import { useAuthStore } from '../store/authStore';
import { Dumbbell, AlertTriangle } from 'lucide-react';
import { isSupabaseConfigured } from '../lib/supabase';

export default function Login() {
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [username, setUsername] = useState('');
  const [error, setError] = useState('');
  const { signIn, signUp } = useAuthStore();
  const supabaseConfigured = isSupabaseConfigured();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    if (!supabaseConfigured) {
      setError('Supabase is not properly configured. Please connect to Supabase first.');
      return;
    }
    
    try {
      if (isLogin) {
        await signIn(email, password);
      } else {
        if (!username) {
          setError('Por favor, elige un ID de usuario');
          return;
        }
        if (username.length < 3) {
          setError('El ID debe tener al menos 3 caracteres');
          return;
        }
        if (!/^[a-zA-Z0-9_-]+$/.test(username)) {
          setError('El ID solo puede contener letras, números, guiones y guiones bajos');
          return;
        }
        await signUp(email, password, username);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'An error occurred');
    }
  };

  if (!supabaseConfigured) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-black p-4">
        <div className="max-w-md w-full space-y-8 bg-gray-900 p-8 rounded-xl">
          <div className="text-center">
            <Dumbbell className="mx-auto h-12 w-12 text-white" />
            <h2 className="mt-6 text-3xl font-extrabold text-white">
              Gym Track Pro
            </h2>
          </div>
          
          <div className="bg-red-900/50 border border-red-700 rounded-lg p-4">
            <div className="flex items-center gap-2 text-red-400 mb-2">
              <AlertTriangle className="h-5 w-5" />
              <h3 className="font-medium">Configuration Required</h3>
            </div>
            <p className="text-sm text-gray-300">
              Please connect to Supabase using the "Connect to Supabase" button in the top right corner.
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-black p-4">
      <div className="max-w-md w-full space-y-8">
        <div className="text-center">
          <Dumbbell className="mx-auto h-12 w-12 text-white" />
          <h2 className="mt-6 text-3xl font-extrabold text-white">
            Gym Track Pro
          </h2>
          <p className="mt-2 text-sm text-gray-400">
            {isLogin ? 'Sign in to your account' : 'Create your account'}
          </p>
        </div>
        
        <form className="mt-8 space-y-6" onSubmit={handleSubmit}>
          {error && (
            <div className="bg-red-500 text-white p-3 rounded-md text-sm">
              {error}
            </div>
          )}
          
          <div className="rounded-md shadow-sm -space-y-px">
            {!isLogin && (
              <div>
                <input
                  type="text"
                  required
                  className="appearance-none rounded-none relative block w-full px-3 py-2 border border-gray-700 placeholder-gray-500 text-white bg-gray-900 rounded-t-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 focus:z-10 sm:text-sm"
                  placeholder="Choose your ID (username)"
                  value={username}
                  onChange={(e) => setUsername(e.target.value.toLowerCase())}
                  pattern="[a-zA-Z0-9_-]+"
                  title="Solo letras, números, guiones y guiones bajos"
                  minLength={3}
                />
              </div>
            )}
            <div>
              <input
                type="email"
                required
                className={`appearance-none rounded-none relative block w-full px-3 py-2 border border-gray-700 placeholder-gray-500 text-white bg-gray-900 ${isLogin ? 'rounded-t-md' : ''} focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 focus:z-10 sm:text-sm`}
                placeholder="Email address"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>
            <div>
              <input
                type="password"
                required
                className="appearance-none rounded-none relative block w-full px-3 py-2 border border-gray-700 placeholder-gray-500 text-white bg-gray-900 rounded-b-md focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 focus:z-10 sm:text-sm"
                placeholder="Password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>
          </div>

          <div>
            <button
              type="submit"
              className="group relative w-full flex justify-center py-2 px-4 border border-transparent text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
            >
              {isLogin ? 'Sign in' : 'Sign up'}
            </button>
          </div>
          
          <div className="text-center">
            <button
              type="button"
              className="text-sm text-indigo-400 hover:text-indigo-500"
              onClick={() => {
                setIsLogin(!isLogin);
                setError('');
                setUsername('');
              }}
            >
              {isLogin
                ? "Don't have an account? Sign up"
                : 'Already have an account? Sign in'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}