import React, { useState, useEffect, useCallback } from 'react';
import { supabase } from '../lib/supabase';
import { useAuthStore } from '../store/authStore';
import { Plus, Edit2, Trash2, X, ChevronDown, Loader2 } from 'lucide-react';

interface Set {
  reps: number;
  weight: number;
}

interface Exercise {
  id?: string;
  name: string;
  sets: Set[];
  notes?: string;
  order_index: number;
}

interface Workout {
  id: string;
  name: string;
  day_of_week: number;
  exercises: Exercise[];
}

const DAYS = ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'];

const DEFAULT_SET: Set = {
  reps: 0,
  weight: 0
};

const DEFAULT_EXERCISE: Exercise = {
  name: '',
  sets: [{ ...DEFAULT_SET }],
  notes: '',
  order_index: 0
};

const ExerciseForm = ({ 
  exercise, 
  onUpdate, 
  onRemove 
}: { 
  exercise: Exercise;
  onUpdate: (exercise: Exercise) => void;
  onRemove: () => void;
}) => {
  const [numSeries, setNumSeries] = useState(exercise.sets.length.toString());

  const generateSeries = () => {
    const num = parseInt(numSeries);
    if (isNaN(num) || num < 1) return;

    const newSets = Array(num).fill(null).map(() => ({
      reps: exercise.sets[0]?.reps || 0,
      weight: exercise.sets[0]?.weight || 0
    }));

    onUpdate({
      ...exercise,
      sets: newSets
    });
  };

  const updateSet = (index: number, field: keyof Set, value: number) => {
    const newSets = [...exercise.sets];
    newSets[index] = {
      ...newSets[index],
      [field]: value
    };
    onUpdate({
      ...exercise,
      sets: newSets
    });
  };

  return (
    <div className="bg-gray-800 p-4 rounded-lg mb-4">
      <div className="flex justify-between items-start mb-4">
        <input
          type="text"
          value={exercise.name}
          onChange={(e) => onUpdate({ ...exercise, name: e.target.value })}
          className="bg-gray-700 text-white px-3 py-2 rounded-md flex-1 mr-2"
          placeholder="Nombre del ejercicio"
        />
        <button
          onClick={(e) => {
            e.preventDefault();
            e.stopPropagation();
            onRemove();
          }}
          type="button"
          className="text-gray-400 hover:text-red-500 transition-colors"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      <div className="mb-4">
        <label className="block text-sm font-medium text-gray-300 mb-1">
          Series
        </label>
        <div className="flex gap-2">
          <input
            type="number"
            min="1"
            value={numSeries}
            onChange={(e) => setNumSeries(e.target.value)}
            className="w-20 px-2 py-1 bg-gray-700 rounded text-white"
          />
          <button
            type="button"
            onClick={generateSeries}
            className="px-3 py-1 bg-indigo-600 text-white rounded hover:bg-indigo-700 transition-colors text-sm"
          >
            Generar Series
          </button>
        </div>
      </div>

      <div className="space-y-3">
        {exercise.sets.map((set, index) => (
          <div key={index} className="flex items-center gap-4">
            <span className="text-sm text-gray-400 w-16">Series {index + 1}</span>
            <input
              type="number"
              value={set.reps}
              onChange={(e) => updateSet(index, 'reps', parseInt(e.target.value) || 0)}
              className="w-20 px-2 py-1 bg-gray-700 rounded text-white"
              placeholder="Repeticiones"
            />
            <input
              type="number"
              value={set.weight}
              onChange={(e) => updateSet(index, 'weight', parseFloat(e.target.value) || 0)}
              className="w-20 px-2 py-1 bg-gray-700 rounded text-white"
              placeholder="Kilogramos"
              step="0.5"
            />
          </div>
        ))}
      </div>

      <div className="mt-4">
        <label className="block text-sm font-medium text-gray-300 mb-1">
          Notas (opcional)
        </label>
        <textarea
          value={exercise.notes}
          onChange={(e) => onUpdate({ ...exercise, notes: e.target.value })}
          className="w-full px-3 py-2 bg-gray-700 rounded-md text-white"
          rows={2}
        />
      </div>
    </div>
  );
};

const WorkoutForm = ({ 
  workout = null,
  onSubmit,
  onCancel
}: { 
  workout?: Workout | null;
  onSubmit: (data: { name: string; day_of_week: number; exercises: Exercise[] }) => Promise<void>;
  onCancel: () => void;
}) => {
  const [name, setName] = useState(workout?.name || '');
  const [dayOfWeek, setDayOfWeek] = useState(workout?.day_of_week || 0);
  const [exercises, setExercises] = useState<Exercise[]>(
    workout?.exercises.map(e => ({
      ...e,
      sets: [...e.sets]
    })) || []
  );
  const [isSaving, setIsSaving] = useState(false);

  const addExercise = () => {
    setExercises(prev => [
      ...prev,
      {
        ...DEFAULT_EXERCISE,
        order_index: prev.length
      }
    ]);
  };

  const updateExercise = (index: number, updatedExercise: Exercise) => {
    setExercises(prev => {
      const newExercises = [...prev];
      newExercises[index] = {
        ...updatedExercise,
        id: prev[index]?.id
      };
      return newExercises;
    });
  };

  const removeExercise = (index: number) => {
    setExercises(prev => {
      const newExercises = prev.filter((_, i) => i !== index);
      return newExercises.map((exercise, newIndex) => ({
        ...exercise,
        order_index: newIndex
      }));
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      setIsSaving(true);

      if (!name.trim()) {
        throw new Error('El nombre de la rutina es requerido');
      }

      if (exercises.length === 0) {
        throw new Error('Debe agregar al menos un ejercicio');
      }

      const validatedExercises = exercises.map((exercise, index) => {
        if (!exercise.name.trim()) {
          throw new Error(`El nombre es requerido para el ejercicio ${index + 1}`);
        }

        if (exercise.sets.length === 0) {
          throw new Error(`Debe agregar al menos una serie al ejercicio ${index + 1}`);
        }

        exercise.sets.forEach((set, setIndex) => {
          if (set.reps <= 0) {
            throw new Error(`Número de repeticiones inválido en la serie ${setIndex + 1} del ejercicio ${index + 1}`);
          }

          if (set.weight < 0) {
            throw new Error(`Peso inválido en la serie ${setIndex + 1} del ejercicio ${index + 1}`);
          }
        });

        return {
          ...exercise,
          id: exercise.id,
          name: exercise.name.trim(),
          notes: exercise.notes?.trim() || '',
          order_index: index,
          sets: exercise.sets.map(set => ({
            ...set,
            reps: Math.max(1, Math.round(set.reps)),
            weight: Math.max(0, Number(set.weight.toFixed(2)))
          }))
        };
      });

      await onSubmit({
        name: name.trim(),
        day_of_week: dayOfWeek,
        exercises: validatedExercises
      });
    } catch (error) {
      alert(error instanceof Error ? error.message : String(error));
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-gray-900 rounded-lg p-6 w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <h2 className="text-xl font-semibold text-white mb-4">
          {workout ? 'Editar Rutina' : 'Nueva Rutina'}
        </h2>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-300 mb-1">
              Nombre de la rutina
            </label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="w-full px-3 py-2 bg-gray-800 border border-gray-700 rounded-md text-white"
              placeholder="Nombre de la rutina"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-300 mb-1">
              Día de la semana
            </label>
            <select
              value={dayOfWeek}
              onChange={(e) => setDayOfWeek(parseInt(e.target.value))}
              className="w-full px-3 py-2 bg-gray-800 border border-gray-700 rounded-md text-white"
            >
              {DAYS.map((day, index) => (
                <option key={index} value={index}>
                  {day}
                </option>
              ))}
            </select>
          </div>

          <div>
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-medium text-white">
                Ejercicios
              </h3>
              <button
                type="button"
                onClick={addExercise}
                className="flex items-center gap-2 px-3 py-1 bg-indigo-600 text-white rounded-md hover:bg-indigo-700 transition-colors text-sm"
              >
                <Plus className="w-4 h-4" />
                Añadir Ejercicio
              </button>
            </div>

            {exercises.map((exercise, index) => (
              <ExerciseForm
                key={index}
                exercise={exercise}
                onUpdate={(updated) => updateExercise(index, updated)}
                onRemove={() => removeExercise(index)}
              />
            ))}

            {exercises.length === 0 && (
              <p className="text-gray-400 text-center py-4">
                No hay ejercicios añadidos
              </p>
            )}
          </div>

          <div className="flex justify-end gap-3 pt-4">
            <button
              type="button"
              onClick={onCancel}
              disabled={isSaving}
              className="px-4 py-2 text-gray-300 hover:text-white transition-colors disabled:opacity-50"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={isSaving}
              className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
            >
              {isSaving ? (
                <div className="flex items-center gap-2">
                  <Loader2 className="w-5 h-5 animate-spin" />
                  <span>Guardando...</span>
                </div>
              ) : (
                'Guardar'
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

const WorkoutCard = React.memo(({ 
  workout,
  onEdit,
  onDelete 
}: { 
  workout: Workout;
  onEdit: (workout: Workout) => void;
  onDelete: (id: string) => void;
}) => {
  const [isExpanded, setIsExpanded] = useState(false);

  return (
    <div className="bg-gray-800 rounded-lg overflow-hidden transition-all duration-200 ease-in-out">
      <div 
        className="flex items-center justify-between p-4 cursor-pointer hover:bg-gray-700 transition-colors"
        onClick={() => setIsExpanded(!isExpanded)}
      >
        <div className="flex items-center gap-3">
          <ChevronDown 
            className={`w-5 h-5 text-gray-400 transition-transform duration-200 ${
              isExpanded ? 'transform rotate-180' : ''
            }`}
          />
          <h3 className="text-lg font-medium text-white">{workout.name}</h3>
        </div>
        <div className="flex gap-2">
          <button
            onClick={(e) => {
              e.stopPropagation();
              onEdit(workout);
            }}
            className="text-gray-400 hover:text-white transition-colors p-1"
          >
            <Edit2 className="w-4 h-4" />
          </button>
          <button
            onClick={(e) => {
              e.stopPropagation();
              if (confirm('¿Estás seguro de que quieres eliminar esta rutina?')) {
                onDelete(workout.id);
              }
            }}
            className="text-gray-400 hover:text-red-500 transition-colors p-1"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>
      
      <div 
        className={`overflow-hidden transition-all duration-200 ease-in-out ${
          isExpanded ? 'max-h-[1000px] opacity-100' : 'max-h-0 opacity-0'
        }`}
      >
        {workout.exercises.length > 0 ? (
          <div className="p-4 pt-0 border-t border-gray-700">
            <ul className="space-y-4">
              {workout.exercises.map((exercise, index) => (
                <li key={index} className="text-gray-300">
                  <div className="font-medium text-sm mb-2">{exercise.name}</div>
                  <div className="space-y-1">
                    {exercise.sets.map((set, setIndex) => (
                      <div key={setIndex} className="text-xs text-gray-400 flex items-center gap-2">
                        <span className="w-16">Series {setIndex + 1}:</span>
                        <span className="flex-1">{set.reps} reps × {set.weight}kg</span>
                      </div>
                    ))}
                  </div>
                  {exercise.notes && (
                    <div className="text-gray-500 text-xs mt-2 italic">{exercise.notes}</div>
                  )}
                </li>
              ))}
            </ul>
          </div>
        ) : (
          <div className="p-4 pt-0 border-t border-gray-700">
            <p className="text-gray-500 text-sm">No hay ejercicios añadidos</p>
          </div>
        )}
      </div>
    </div>
  );
});

export default function Workouts() {
  const { user } = useAuthStore();
  const [workouts, setWorkouts] = useState<Workout[]>([]);
  const [isAddingWorkout, setIsAddingWorkout] = useState(false);
  const [editingWorkout, setEditingWorkout] = useState<Workout | null>(null);

  const fetchWorkouts = useCallback(async () => {
    if (!user) return;

    try {
      const { data: workoutsData, error: workoutsError } = await supabase
        .from('workouts')
        .select(`
          id,
          name,
          day_of_week,
          exercises (
            id,
            name,
            notes,
            order_index,
            sets (
              reps,
              weight
            )
          )
        `)
        .eq('user_id', user.id)
        .order('day_of_week, order_index');

      if (workoutsError) throw workoutsError;

      const transformedWorkouts = (workoutsData || []).map(workout => ({
        ...workout,
        exercises: workout.exercises.map(exercise => ({
          ...exercise,
          sets: exercise.sets || []
        })).sort((a, b) => a.order_index - b.order_index)
      }));

      setWorkouts(transformedWorkouts);
    } catch (error) {
      console.error('Error fetching workouts:', error);
    }
  }, [user]);

  useEffect(() => {
    fetchWorkouts();
  }, [fetchWorkouts]);

  const handleAddWorkout = async (workoutData: { name: string; day_of_week: number; exercises: Exercise[] }) => {
    try {
      if (!user) return;

      // 1. Insert workout
      const { data: workout, error: workoutError } = await supabase
        .from('workouts')
        .insert([{
          name: workoutData.name,
          day_of_week: workoutData.day_of_week,
          user_id: user.id
        }])
        .select()
        .single();

      if (workoutError) throw workoutError;

      // 2. Insert exercises
      for (const exercise of workoutData.exercises) {
        const { data: exerciseData, error: exerciseError } = await supabase
          .from('exercises')
          .insert([{
            workout_id: workout.id,
            name: exercise.name,
            notes: exercise.notes || '',
            order_index: exercise.order_index
          }])
          .select()
          .single();

        if (exerciseError) throw exerciseError;

        // 3. Insert sets for each exercise
        const setsToInsert = exercise.sets.map(set => ({
          exercise_id: exerciseData.id,
          reps: set.reps,
          weight: set.weight
        }));

        const { error: setsError } = await supabase
          .from('sets')
          .insert(setsToInsert);

        if (setsError) throw setsError;
      }

      await fetchWorkouts();
      setIsAddingWorkout(false);
    } catch (error) {
      console.error('Error adding workout:', error);
      throw error;
    }
  };

  const handleEditWorkout = async (workoutData: { name: string; day_of_week: number; exercises: Exercise[] }) => {
    try {
      if (!user || !editingWorkout) return;

      // 1. Update basic workout information
      const { error: workoutError } = await supabase
        .from('workouts')
        .update({
          name: workoutData.name,
          day_of_week: workoutData.day_of_week,
          updated_at: new Date().toISOString()
        })
        .eq('id', editingWorkout.id);

      if (workoutError) throw workoutError;

      // 2. Get existing exercises
      const { data: existingExercises, error: getExercisesError } = await supabase
        .from('exercises')
        .select('id')
        .eq('workout_id', editingWorkout.id);

      if (getExercisesError) throw getExercisesError;

      const existingIds = existingExercises?.map(e => e.id) || [];
      const newExerciseIds = workoutData.exercises.map(e => e.id).filter(Boolean);
      
      // Find exercises to delete (those in existing but not in new)
      const exercisesToDelete = existingIds.filter(id => !newExerciseIds.includes(id));

      // Delete removed exercises
      if (exercisesToDelete.length > 0) {
        const { error: deleteError } = await supabase
          .from('exercises')
          .delete()
          .in('id', exercisesToDelete);

        if (deleteError) throw deleteError;
      }

      // 3. Process each exercise
      for (const exercise of workoutData.exercises) {
        if (exercise.id) {
          // Update existing exercise
          const { error: exerciseError } = await supabase
            .from('exercises')
            .update({
              name: exercise.name,
              notes: exercise.notes || '',
              order_index: exercise.order_index,
              updated_at: new Date().toISOString()
            })
            .eq('id', exercise.id);

          if (exerciseError) throw exerciseError;

          // Delete existing sets
          const { error: deleteSetsError } = await supabase
            .from('sets')
            .delete()
            .eq('exercise_id', exercise.id);

          if (deleteSetsError) throw deleteSetsError;
        } else {
          // Create new exercise
          const { data: newExercise, error: exerciseError } = await supabase
            .from('exercises')
            .insert([{
              workout_id: editingWorkout.id,
              name: exercise.name,
              notes: exercise.notes || '',
              order_index: exercise.order_index
            }])
            .select()
            .single();

          if (exerciseError) throw exerciseError;
          exercise.id = newExercise.id;
        }

        // Insert new sets
        if (exercise.id) {
          const setsToInsert = exercise.sets.map(set => ({
            exercise_id: exercise.id,
            reps: set.reps,
            weight: set.weight
          }));

          const { error: setsError } = await supabase
            .from('sets')
            .insert(setsToInsert);

          if (setsError) throw setsError;
        }
      }

      await fetchWorkouts();
      setEditingWorkout(null);
    } catch (error) {
      console.error('Error updating workout:', error);
      throw error;
    }
  };

  const handleDeleteWorkout = async (id: string) => {
    try {
      const { error } = await supabase
        .from('workouts')
        .delete()
        .eq('id', id);

      if (error) throw error;

      await fetchWorkouts();
    } catch (error) {
      console.error('Error deleting workout:', error);
      alert('Error al eliminar la rutina');
    }
  };

  return (
    <div className="max-w-6xl mx-auto px-4">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-3xl font-bold text-white">Mis Rutinas</h1>
        <button
          onClick={() => setIsAddingWorkout(true)}
          className="flex items-center gap-2 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors"
        >
          <Plus className="w-5 h-5" />
          Nueva Rutina
        </button>
      </div>

      {(isAddingWorkout || editingWorkout) && (
        <WorkoutForm
          workout={editingWorkout}
          onSubmit={editingWorkout ? handleEditWorkout : handleAddWorkout}
          onCancel={() => {
            setIsAddingWorkout(false);
            setEditingWorkout(null);
          }}
        />
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {DAYS.map((day, index) => {
          const dayWorkouts = workouts.filter(w => w.day_of_week === index);
          return (
            <div key={index} className="bg-gray-900 rounded-lg p-6">
              <h2 className="text-xl font-semibold text-white mb-4">{day}</h2>
              {dayWorkouts.length === 0 ? (
                <p className="text-gray-400">No hay rutinas para este día</p>
              ) : (
                <div className="space-y-4">
                  {dayWorkouts.map(workout => (
                    <WorkoutCard
                      key={workout.id}
                      workout={workout}
                      onEdit={setEditingWorkout}
                      onDelete={handleDeleteWorkout}
                    />
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}